Google Tag Manager Android SDK

Copyright 2013 Google, Inc. All rights reserved.

================================================================================
DESCRIPTION:

This SDK provides developers with the capability to use Google Tag Manager
to do server-side rule-based customization of configuration variables.

The SDK is packaged as a jar file (in the root directory), a directory
containing examples, the file Changelog.txt and this file (Readme.txt).

Details on how to use this SDK are available at:
  http://developers.google.com/tag-manager/android

================================================================================
BUILD REQUIREMENTS:

Android SDK 2.1+

================================================================================
RUNTIME REQUIREMENTS:

Android SDK 2.1+
